<!DOCTYPE html>
<html lang="en-us">
<head>
	<script type="text/javascript">
			</script>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars((isset($seoTitle) && $seoTitle !== "") ? $seoTitle : "Analytics"); ?></title>
	<base href="{{base_url}}" />
	<?php echo isset($sitemapUrls) ? generateCanonicalUrl($sitemapUrls) : ""; ?>	
	
						<meta name="viewport" content="width=device-width, initial-scale=1" />
					<meta name="description" content="<?php echo htmlspecialchars((isset($seoDescription) && $seoDescription !== "") ? $seoDescription : "Analytics"); ?>" />
			<meta name="keywords" content="<?php echo htmlspecialchars((isset($seoKeywords) && $seoKeywords !== "") ? $seoKeywords : "Analytics"); ?>" />
		
	<!-- Facebook Open Graph -->
		<meta property="og:title" content="<?php echo htmlspecialchars((isset($seoTitle) && $seoTitle !== "") ? $seoTitle : "Analytics"); ?>" />
			<meta property="og:description" content="<?php echo htmlspecialchars((isset($seoDescription) && $seoDescription !== "") ? $seoDescription : "Analytics"); ?>" />
			<meta property="og:image" content="<?php echo htmlspecialchars((isset($seoImage) && $seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
			<meta property="og:type" content="article" />
			<meta property="og:url" content="{{curr_url}}" />
		<!-- Facebook Open Graph end -->

		<meta name="generator" content="Website Builder" />
			<script src="js/common-bundle.js?ts=20240424225725" type="text/javascript"></script>
	<script src="js/a18e09b5bc7402d24013751e3eff3990-bundle.js?ts=20240424225725" type="text/javascript"></script>
	<link href="css/common-bundle.css?ts=20240424225725" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin,latin-ext,vietnamese" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin,latin-ext,vietnamese" rel="stylesheet" type="text/css" />
	<link href="css/a18e09b5bc7402d24013751e3eff3990-bundle.css?ts=20240424225725" rel="stylesheet" type="text/css" id="wb-page-stylesheet" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
	window.disableRightClick = false;
	window.currLang = 'en';
</script>
		
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

		<script type="text/javascript">
		$(function () {
<?php $wb_form_send_success = popSessionOrGlobalVar("wb_form_send_success"); ?>
<?php if (($wb_form_send_state = popSessionOrGlobalVar("wb_form_send_state"))) { ?>
	<?php if (($wb_form_popup_mode = popSessionOrGlobalVar("wb_form_popup_mode")) && (isset($wbPopupMode) && $wbPopupMode)) { ?>
		if (window !== window.parent && window.parent.postMessage) {
			var data = {
				event: "wb_contact_form_sent",
				data: {
					state: "<?php echo str_replace('"', '\"', $wb_form_send_state); ?>",
					type: "<?php echo $wb_form_send_success ? "success" : "danger"; ?>"
				}
			};
			window.parent.postMessage(data, "<?php echo str_replace('"', '\"', popSessionOrGlobalVar("wb_target_origin")); ?>");
		}
	<?php $wb_form_send_success = false; $wb_form_send_state = null; $wb_form_popup_mode = false; ?>
	<?php } else { ?>
		wb_show_alert("<?php echo str_replace(array('"', "\r", "\n"), array('\"', "", "<br/>"), $wb_form_send_state); ?>", "<?php echo $wb_form_send_success ? "success" : "danger"; ?>");
	<?php } ?>
<?php } ?>
});    </script>
</head>


<body class="site site-lang-en<?php if (isset($wbPopupMode) && $wbPopupMode) echo ' popup-mode'; ?> " <?php ?>><div id="wb_root" class="root wb-layout-vertical"><div class="wb_sbg"></div><div id="wb_header_a18e09b5bc7402d24013751e3eff3990" class="wb_element wb-sticky wb-layout-element" data-plugin="LayoutElement" data-h-align="center" data-v-align="top"><div class="wb_content wb-layout-vertical"><div id="a18e09b561630f7be06d75cc17eaeec6" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b56163104e0e0ddc5813d52b49" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b56163111b84cb67976699e898" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><a href="https://www.tradeforward.io/"><img alt="" src="gallery_gen/5629ab6b9d1e0502d030cf8e37f5d42e_596x188_fit.jpg?ts=1713988649"></a></div></div></div><div id="a18e09b5616312cc20bbe7385fbd5a5b" class="wb_element wb-menu wb-prevent-layout-click wb-menu-mobile" data-plugin="Menu"><a class="btn btn-default btn-collapser"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a><ul class="hmenu" dir="ltr"><li class=""><a href="{{base_url}}">Home</a></li><li class=""><a href="About/">About</a></li><li class="wb_this_page_menu_item"><a href="Analytics/">Analytics</a></li><li class=""><a href="Services/">Services</a></li><li class=""><a href="Partners/">Partners</a></li><li class=""><a href="Contact/">Contact</a></li></ul><div class="clearfix"></div></div></div></div></div></div></div></div><div id="wb_main_a18e09b5bc7402d24013751e3eff3990" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616400b0c71de333bdeb49d4" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616401448ab8eb4e12ba0a88" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"></div></div></div></div><div id="a18e09b5616402f52f5d7f0f00461846" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616403d8dc0596753b9b61f3" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561640485144c3e99bdf38ae2" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h5 class="wb-stl-custom1" data-dnid="30148">DATA ANALYTICS</h5></div></div></div></div></div><div id="a18e09b5616405e285231e0099914881" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616406b53e07f5d80488d33d" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><img alt="" src="gallery/Trade%20Analytics-ts1594925980.jpg?ts=1713988649"></div></div></div><div id="a18e09b5616407bdd1c21cac86c8d59c" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom17" data-dnid="30117">TRADE DATA ANALYTICS</p><p class="wb-stl-custom18" data-dnid="30119"> </p><p class="wb-stl-custom19" data-dnid="30121">Charts, reporting tables, and graphs only visualize the current state of your trade programs. Using the data from multiple systems, multiple service providers, and multiple sources can be a challenge to simply build these visualizations. By eliminating data "silos", addressing data quality, documenting data relationships, managing the mapping process and the frequency of data updates, insight into any process or operation becomes both tactical and strategic.</p><p class="wb-stl-custom20" data-dnid="30123"> </p><p class="wb-stl-custom19" data-dnid="30125">The approach from Trade Forward is to develop targeted insights based on our trade experience, knowledge of your business process, and using your data sources. Rather than simply visualize the reality, we can define the best sources to achieve the most efficient use of your data and tell the story of your program’s success and opportunities with minimal involvement from internal resources.</p></div></div></div><div id="a18e09b5616408c6daf8b1189a1408e0" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616409ed940ed1d4afb6db67" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b561640afac4564cc14d072a9e" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><img alt="" src="gallery_gen/8256af5df48c31e04247695f2c3c1f71_fit.jpg?ts=1713988649"></div></div></div><div id="a18e09b561640b4d590a5844a292bfde" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom21" data-dnid="30127">DUTY OPTIMIZATION</p><p class="wb-stl-custom18" data-dnid="30129"> </p><p class="wb-stl-custom11" data-dnid="30131">Duty optimization is part of every viable global trade strategy. Analysis using origins, transactional volumes, specific commodities, expansive parties, and diverse supply chain network partners can identify potential savings often hidden within the supply chain. Reporting on the data simply visualizes the current situation. Analysis can test potential solutions often overlooked or even expand opportunities that were often disregarded.</p><p class="wb-stl-custom20" data-dnid="30133"> </p><p class="wb-stl-custom11" data-dnid="30135">Duty drawback, value and FTA reconciliation, foreign trade zones, and duty deferral strategies are some of the obvious activities that can be included or excluded from a strategy by reviewing trade data and making determinations. Often, analysis of existing transactional data can identify classifications that are not aligned globally along with missed opportunities to recapture cost of cash savings through special government programs.</p></div></div></div></div></div><div id="a18e09b561640c5a90cf3e384e68f215" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b561640d2957a9fe65109134c7" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><img alt="" src="gallery/Scorecard%201-ts1594927238.jpg?ts=1713988649"></div></div></div><div id="a18e09b561640e72abc6f8f30d6f88d5" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom17" data-dnid="30138">SCORECARDS</p><p class="wb-stl-custom18" data-dnid="30140"> </p><p class="wb-stl-custom19" data-dnid="30142">Reports and visual metrics are not scorecards. Evaluating service partners against a standard of performance success requires reporting that benchmarks these standards and then evaluates performance against these standards. Scorecards remain one of the highly sought tools to manage service partner and compliance relationships. Most business methodologies and corporate programs include components of continuous improvement to drive organizational success.</p><p class="wb-stl-custom20" data-dnid="30144"> </p><p class="wb-stl-custom19" data-dnid="30146">Many companies use more than two customs brokers to manage their entry declarations across several supply chain designs including air and ocean shipments, border crossings, and express clearance. While most service providers allow clients to recover their data and documents, the challenge is aggregating the data from all providers to represent the true performance of the trade program.</p></div></div></div></div></div><div id="wb_footer_a18e09b5bc7402d24013751e3eff3990" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616410561c76eafb201be910" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616411a6d126a3b839d77c80" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b561650049a1f43645cdd3072a" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom9" data-dnid="30157">17319 Inglewood Ln</p></div><div id="a18e09b5616501e0c21a1ee955602b34" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="30164">Follow Us</p></div><div id="a18e09b56165025a8e06d2217e66e362" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="30161">© 2023 Trade Forward LLC</p></div></div></div><div id="a18e09b5616503092c8a75db42407e73" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b56165049921e54d30d7470d87" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom9" data-dnid="30166">Huntersville, NC 28078</p></div><div id="a18e09b5616505f6fe59e9b892e59774" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap" style="height: 100%"><div class="wb-picture-wrapper" style="overflow: visible; display: flex"><a href="https://www.linkedin.com/company/trade-forward-llc/?viewAsMember=true" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="1793.982" height="1793.982" viewBox="0 0 1793.982 1793.982" style="direction: ltr; color:#ffffff"><text x="129.501415" y="1537.02" font-size="1792" fill="currentColor" style='font-family: "FontAwesome"'></text></svg></a></div></div></div><div id="a18e09b5616506d9b455e0d2e7819e70" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="30159">1-800-925-9557</p></div></div></div></div></div><div id="wb_footer_c" class="wb_element" data-plugin="WB_Footer" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#footer, #footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div></div></div>{{hr_out}}</body>
</html>
