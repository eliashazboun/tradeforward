<!DOCTYPE html>
<html lang="en-us">
<head>
	<script type="text/javascript">
			</script>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars((isset($seoTitle) && $seoTitle !== "") ? $seoTitle : "Contact"); ?></title>
	<base href="{{base_url}}" />
	<?php echo isset($sitemapUrls) ? generateCanonicalUrl($sitemapUrls) : ""; ?>	
	
						<meta name="viewport" content="width=device-width, initial-scale=1" />
					<meta name="description" content="<?php echo htmlspecialchars((isset($seoDescription) && $seoDescription !== "") ? $seoDescription : "Contact"); ?>" />
			<meta name="keywords" content="<?php echo htmlspecialchars((isset($seoKeywords) && $seoKeywords !== "") ? $seoKeywords : "Contact"); ?>" />
		
	<!-- Facebook Open Graph -->
		<meta property="og:title" content="<?php echo htmlspecialchars((isset($seoTitle) && $seoTitle !== "") ? $seoTitle : "Contact"); ?>" />
			<meta property="og:description" content="<?php echo htmlspecialchars((isset($seoDescription) && $seoDescription !== "") ? $seoDescription : "Contact"); ?>" />
			<meta property="og:image" content="<?php echo htmlspecialchars((isset($seoImage) && $seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
			<meta property="og:type" content="article" />
			<meta property="og:url" content="{{curr_url}}" />
		<!-- Facebook Open Graph end -->

		<meta name="generator" content="Website Builder" />
			<script src="js/common-bundle.js?ts=20240424225725" type="text/javascript"></script>
	<script src="js/a18e09b5bc7405a075c3c8125effe3e6-bundle.js?ts=20240424225725" type="text/javascript"></script>
	<link href="css/common-bundle.css?ts=20240424225725" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin,latin-ext,vietnamese" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin,latin-ext,vietnamese" rel="stylesheet" type="text/css" />
	<link href="css/a18e09b5bc7405a075c3c8125effe3e6-bundle.css?ts=20240424225725" rel="stylesheet" type="text/css" id="wb-page-stylesheet" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
	window.disableRightClick = false;
	window.currLang = 'en';
</script>
		
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

		<script type="text/javascript">
		$(function () {
<?php $wb_form_send_success = popSessionOrGlobalVar("wb_form_send_success"); ?>
<?php if (($wb_form_send_state = popSessionOrGlobalVar("wb_form_send_state"))) { ?>
	<?php if (($wb_form_popup_mode = popSessionOrGlobalVar("wb_form_popup_mode")) && (isset($wbPopupMode) && $wbPopupMode)) { ?>
		if (window !== window.parent && window.parent.postMessage) {
			var data = {
				event: "wb_contact_form_sent",
				data: {
					state: "<?php echo str_replace('"', '\"', $wb_form_send_state); ?>",
					type: "<?php echo $wb_form_send_success ? "success" : "danger"; ?>"
				}
			};
			window.parent.postMessage(data, "<?php echo str_replace('"', '\"', popSessionOrGlobalVar("wb_target_origin")); ?>");
		}
	<?php $wb_form_send_success = false; $wb_form_send_state = null; $wb_form_popup_mode = false; ?>
	<?php } else { ?>
		wb_show_alert("<?php echo str_replace(array('"', "\r", "\n"), array('\"', "", "<br/>"), $wb_form_send_state); ?>", "<?php echo $wb_form_send_success ? "success" : "danger"; ?>");
	<?php } ?>
<?php } ?>
});    </script>
</head>


<body class="site site-lang-en<?php if (isset($wbPopupMode) && $wbPopupMode) echo ' popup-mode'; ?> " <?php ?>><div id="wb_root" class="root wb-layout-vertical"><div class="wb_sbg"></div><div id="wb_header_a18e09b5bc7405a075c3c8125effe3e6" class="wb_element wb-sticky wb-layout-element" data-plugin="LayoutElement" data-h-align="center" data-v-align="top"><div class="wb_content wb-layout-vertical"><div id="a18e09b561690865dea3a73c8e0fe6da" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b56169099b738549806e3be8af" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b561690a2744faf7b3ef45dcbd" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><a href="https://www.tradeforward.io/"><img alt="" src="gallery_gen/5629ab6b9d1e0502d030cf8e37f5d42e_596x188_fit.jpg?ts=1713988652"></a></div></div></div><div id="a18e09b561690b4059e418690980dacd" class="wb_element wb-menu wb-prevent-layout-click wb-menu-mobile" data-plugin="Menu"><a class="btn btn-default btn-collapser"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a><ul class="hmenu" dir="ltr"><li class=""><a href="{{base_url}}">Home</a></li><li class=""><a href="About/">About</a></li><li class=""><a href="Analytics/">Analytics</a></li><li class=""><a href="Services/">Services</a></li><li class=""><a href="Partners/">Partners</a></li><li class="wb_this_page_menu_item"><a href="Contact/">Contact</a></li></ul><div class="clearfix"></div></div></div></div></div></div></div></div><div id="wb_main_a18e09b5bc7405a075c3c8125effe3e6" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561690df0c633ff64cded02e3" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b561690ea8432eafe093251f82" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"></div></div></div></div><div id="a18e09b561690f1d7257dc29fc171bb1" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616910839e3192093950e0b4" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b56169112f2c50563d992f4e44" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h5 class="wb-stl-custom1" data-dnid="60131">WE WANT TO HEAR FROM YOU</h5></div></div></div></div></div><div id="a18e09b56169126e509bd37e492ff0e8" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616a00a31aa651964e0588cd" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616a01ee5ccd12bf1752666b" class="wb_element wb-map wb-prevent-layout-click" data-plugin="bing_maps"><div id="a18e09b5616a01ee5ccd12bf1752666b_myMap" class="bingmap" style="position: relative; min-width: 200px; width: 100%; height: 100%;"></div>
<script type="text/javascript" src="https://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
	(function() {
		var getMap_a18e09b5616a01ee5ccd12bf1752666b = function() {
			Microsoft.Maps.loadModule('Microsoft.Maps.Themes.BingTheme', { callback: function() {
				map_a18e09b5616a01ee5ccd12bf1752666b = new Microsoft.Maps.Map(document.getElementById('a18e09b5616a01ee5ccd12bf1752666b_myMap'), { 
					credentials: 'AsZ3ecKHNQFtwOTJhwlXKZT6mSe1adAYPpdyDPiVK566dwXtYMZQylYbqO5yaxfe', 
					mapTypeId: ("r" || Microsoft.Maps.MapTypeId.road),
					theme: new Microsoft.Maps.Themes.BingTheme(),
					zoom: 10,
					center: new Microsoft.Maps.Location(Number("35.4525189").valueOf(), Number("-80.8795404").valueOf())
				});
				var pushpin= new Microsoft.Maps.Pushpin(map_a18e09b5616a01ee5ccd12bf1752666b.getCenter(), null);
				pushpin.setLocation(new Microsoft.Maps.Location(Number("35.4525189").valueOf(), Number("-80.8795404").valueOf()));
				map_a18e09b5616a01ee5ccd12bf1752666b.entities.push(pushpin)
			}});
		}
		twait = function() {
			if (window.Microsoft && window.Microsoft.Maps && typeof window.Microsoft.Maps.loadModule === 'function') {
				getMap_a18e09b5616a01ee5ccd12bf1752666b();
				return;
			}
			setTimeout(twait, 100);
		};
		twait();
	})();
</script>
</div><div id="a18e09b5616a0231c3f725e1939278b8" class="wb_element" data-plugin="Form"><form id="a18e09b5616a0231c3f725e1939278b8_form" class="wb_form wb_mob_form wb_form_ltr wb_form_vertical" method="post" enctype="multipart/form-data" action="__wb_curr_url__"><input type="hidden" name="wb_form_id" value="f18ea385"><input type="hidden" name="wb_form_uuid" value="db69630c"><textarea name="message" rows="3" cols="20" class="hpc" autocomplete="off"></textarea><table><tr><th>Your Name<span class="text-danger">&nbsp;*</span></th><td><input type="hidden" name="wb_input_0" value="Your Name"><div><input class="form-control form-field" type="text" value="" placeholder="" maxlength="255" name="wb_input_0" required="required"></div></td></tr><tr><th>Your Email<span class="text-danger">&nbsp;*</span></th><td><input type="hidden" name="wb_input_1" value="Your Email"><div><input class="form-control form-field" type="text" value="" placeholder="" maxlength="255" name="wb_input_1" required="required"></div></td></tr><tr><th>Your Phone Number<span class="text-danger">&nbsp;*</span></th><td><input type="hidden" name="wb_input_2" value="Your Phone Number"><div><input class="form-control form-field" type="text" value="" placeholder="" maxlength="255" name="wb_input_2" required="required"></div></td></tr><tr><th>How Did You Find Us?<span class="text-danger">&nbsp;*</span></th><td><input type="hidden" name="wb_input_3" value="How Did You Find Us?"><div><select class="form-control form-field" name="wb_input_3" required="required"><option disabled selected></option><option value="1">Search Engine</option><option value="2">Social Media</option><option value="3">Email Campaign</option><option value="4">Word of Mouth</option><option value="5">Other</option></select></div></td></tr><tr><th>What Is Your Interest?<span class="text-danger">&nbsp;*</span></th><td><input type="hidden" name="wb_input_4" value="What Is Your Interest?"><div><select class="form-control form-field" name="wb_input_4" required="required"><option disabled selected></option><option value="1">Analytics</option><option value="2">Services</option><option value="3">Other</option></select></div></td></tr><tr class="area-row"><th>Your Message<span class="text-danger">&nbsp;*</span></th><td><input type="hidden" name="wb_input_5" value="Your Message"><div><textarea class="form-control form-field form-area-field" rows="4" placeholder="" name="wb_input_5" required="required"></textarea></div></td></tr><tr class="form-footer"><td colspan="2" class="text-right"><button type="submit" class="btn btn-default"><span>Submit</span></button></td></tr></table><?php if (isset($wbPopupMode) && $wbPopupMode): ?><input type="hidden" name="wb_popup_mode" value="1" /><?php endif; ?></form><script type="text/javascript">
			<?php $wb_form_id = sessionOrGlobalVar("wb_form_id"); if ($wb_form_id == "f18ea385") { ?>
				<?php popSessionOrGlobalVar("wb_form_id"); ?>
				var formValues = <?php echo json_encode(popSessionOrGlobalVar("post")); ?>;
				var formErrors = <?php echo json_encode(popSessionOrGlobalVar("formErrors")); ?>;
				wb_form_validateForm("f18ea385", formValues, formErrors);
			<?php } ?>
			</script></div></div></div></div></div><div id="a18e09b5616a0386ddc6f46dd94d5bf0" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616a04233b507831651d94bd" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom23" data-dnid="60133">ddddddd</p></div></div></div></div></div><div id="wb_footer_a18e09b5bc7405a075c3c8125effe3e6" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616a06b1d26d3a2cff769dd6" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616a07da7c3ef78e032c3303" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616a08db6f1d5b4bd5528064" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom9" data-dnid="60143">17319 Inglewood Ln</p></div><div id="a18e09b5616a09d975ce8947a920e1df" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="60150">Follow Us</p></div><div id="a18e09b5616a0a4895c34cf016460102" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="60147">© 2023 Trade Forward LLC</p></div></div></div><div id="a18e09b5616a0bf8869be8a284674f37" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616a0c61bdb7e2135ef43e39" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom9" data-dnid="60152">Huntersville, NC 28078</p></div><div id="a18e09b5616a0d93319eea0a3b7d8baa" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap" style="height: 100%"><div class="wb-picture-wrapper" style="overflow: visible; display: flex"><a href="https://www.linkedin.com/company/trade-forward-llc/?viewAsMember=true" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="1793.982" height="1793.982" viewBox="0 0 1793.982 1793.982" style="direction: ltr; color:#ffffff"><text x="129.501415" y="1537.02" font-size="1792" fill="currentColor" style='font-family: "FontAwesome"'></text></svg></a></div></div></div><div id="a18e09b5616a0e915ebc0aa77c10d3fd" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="60145">1-800-925-9557</p></div></div></div></div></div><div id="wb_footer_c" class="wb_element" data-plugin="WB_Footer" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#footer, #footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div></div></div>{{hr_out}}</body>
</html>
