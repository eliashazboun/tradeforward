<!DOCTYPE html>
<html lang="en-us">
<head>
	<script type="text/javascript">
			</script>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars((isset($seoTitle) && $seoTitle !== "") ? $seoTitle : "Home"); ?></title>
	<base href="{{base_url}}" />
	<?php echo isset($sitemapUrls) ? generateCanonicalUrl($sitemapUrls) : ""; ?>	
	
						<meta name="viewport" content="width=device-width, initial-scale=1" />
					<meta name="description" content="<?php echo htmlspecialchars((isset($seoDescription) && $seoDescription !== "") ? $seoDescription : "Home"); ?>" />
			<meta name="keywords" content="<?php echo htmlspecialchars((isset($seoKeywords) && $seoKeywords !== "") ? $seoKeywords : "Home"); ?>" />
		
	<!-- Facebook Open Graph -->
		<meta property="og:title" content="<?php echo htmlspecialchars((isset($seoTitle) && $seoTitle !== "") ? $seoTitle : "Home"); ?>" />
			<meta property="og:description" content="<?php echo htmlspecialchars((isset($seoDescription) && $seoDescription !== "") ? $seoDescription : "Home"); ?>" />
			<meta property="og:image" content="<?php echo htmlspecialchars((isset($seoImage) && $seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
			<meta property="og:type" content="article" />
			<meta property="og:url" content="{{curr_url}}" />
		<!-- Facebook Open Graph end -->

		<meta name="generator" content="Website Builder" />
			<script src="js/common-bundle.js?ts=20240424225725" type="text/javascript"></script>
	<script src="js/a18e09b5bc7400dd82335abe9162dd86-bundle.js?ts=20240424225725" type="text/javascript"></script>
	<link href="css/common-bundle.css?ts=20240424225725" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin,latin-ext,vietnamese" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin,latin-ext,vietnamese" rel="stylesheet" type="text/css" />
	<link href="css/a18e09b5bc7400dd82335abe9162dd86-bundle.css?ts=20240424225725" rel="stylesheet" type="text/css" id="wb-page-stylesheet" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
	window.disableRightClick = false;
	window.currLang = 'en';
</script>
		
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

		<script type="text/javascript">
		$(function () {
<?php $wb_form_send_success = popSessionOrGlobalVar("wb_form_send_success"); ?>
<?php if (($wb_form_send_state = popSessionOrGlobalVar("wb_form_send_state"))) { ?>
	<?php if (($wb_form_popup_mode = popSessionOrGlobalVar("wb_form_popup_mode")) && (isset($wbPopupMode) && $wbPopupMode)) { ?>
		if (window !== window.parent && window.parent.postMessage) {
			var data = {
				event: "wb_contact_form_sent",
				data: {
					state: "<?php echo str_replace('"', '\"', $wb_form_send_state); ?>",
					type: "<?php echo $wb_form_send_success ? "success" : "danger"; ?>"
				}
			};
			window.parent.postMessage(data, "<?php echo str_replace('"', '\"', popSessionOrGlobalVar("wb_target_origin")); ?>");
		}
	<?php $wb_form_send_success = false; $wb_form_send_state = null; $wb_form_popup_mode = false; ?>
	<?php } else { ?>
		wb_show_alert("<?php echo str_replace(array('"', "\r", "\n"), array('\"', "", "<br/>"), $wb_form_send_state); ?>", "<?php echo $wb_form_send_success ? "success" : "danger"; ?>");
	<?php } ?>
<?php } ?>
});    </script>
</head>


<body class="site site-lang-en<?php if (isset($wbPopupMode) && $wbPopupMode) echo ' popup-mode'; ?> " <?php ?>><div id="wb_root" class="root wb-layout-vertical"><div class="wb_sbg"></div><div id="wb_header_a18e09b5bc7400dd82335abe9162dd86" class="wb_element wb-sticky wb-layout-element" data-plugin="LayoutElement" data-h-align="center" data-v-align="top"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616101290bf066e21cc8bb65" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616102939602d6c2319adb31" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616103e1feeaf5cedb17a33a" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><a href="https://www.tradeforward.io/"><img alt="" src="gallery_gen/5629ab6b9d1e0502d030cf8e37f5d42e_596x188_fit.jpg?ts=1713988646"></a></div></div></div><div id="a18e09b56161046ea24dfe4bb7503eee" class="wb_element wb-menu wb-prevent-layout-click wb-menu-mobile" data-plugin="Menu"><a class="btn btn-default btn-collapser"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a><ul class="hmenu" dir="ltr"><li class="wb_this_page_menu_item"><a href="{{base_url}}">Home</a></li><li class=""><a href="About/">About</a></li><li class=""><a href="Analytics/">Analytics</a></li><li class=""><a href="Services/">Services</a></li><li class=""><a href="Partners/">Partners</a></li><li class=""><a href="Contact/">Contact</a></li></ul><div class="clearfix"></div></div></div></div></div></div></div></div><div id="wb_main_a18e09b5bc7400dd82335abe9162dd86" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616106113fe8a5bfe60b8459" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616200269caa80f7d315160e" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"></div></div></div></div><div id="a18e09b5616201adaa0702ae1ddf3d9a" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616202b1f41b63d70f58170c" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561620391c52eea059d6d76bc" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616204506d73505312ab0891" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h5 class="wb-stl-custom1" data-dnid="10162">CONNECTING SUPPLY CHAIN &amp; GLOBAL TRADE</h5>
</div></div></div></div></div></div></div><div id="a18e09b56162052f02c248ee203a9171" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616206225161df7d2598e751" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616207d56d1b63bfa19c55f8" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-custom3" data-dnid="10131">analytics</h3></div><div id="a18e09b5616208703093ab8ff3704883" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><img alt="" src="gallery_gen/10541033d7bb73a8d9362058dc069d10_620x466_fit.jpg?ts=1713988647"></div></div></div><div id="a18e09b56162091bc8439676ba38cbaf" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom4" data-dnid="10144">Complete visibility, analysis, and real-time performance reporting into global trade and supply chain operations</p></div><div id="a18e09b561620a3717ffe58d74fc7714" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom5" data-dnid="10160"><a href="https://www.tradeforward.io/Analytics/">More Info</a></p></div></div></div><div id="a18e09b561620b44ea0e227502fb3a47" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561620cd852826edbeca01d3c" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-custom3" data-dnid="10133">Services</h3></div><div id="a18e09b561620d658129e1f2305045c8" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><img alt="" src="gallery_gen/b37cc4b1dcc81813d33fe776b36993a4_612x408_fit.jpg?ts=1713988647"></div></div></div><div id="a18e09b561620e118a48984744d2e0ae" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom4" data-dnid="10142">Best-in-breed process automation, system design and implementation through expertise and collaboration</p></div><div id="a18e09b561620fc8942a7541a2f08955" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom5" data-dnid="10154"><a href="https://www.tradeforward.io/Services/">More Info</a></p></div></div></div><div id="a18e09b56162100a530f5748e89b73e2" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616211631c54f6cfde30e28e" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-custom3" data-dnid="10135">Partners</h3></div><div id="a18e09b5616212cf37aa7f0d1f23bbab" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><img alt="" src="gallery_gen/5f004fe549699310d0a56c8b8e2b0f19_fit.jpg?ts=1713988647"></div></div></div><div id="a18e09b561621362f7dc3d53e3f72362" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom6" data-dnid="10140">Strategic go-to-market partnerships with industry leaders in data analytics and global trade management</p></div><div id="a18e09b5616214ed7178c3e186cbee2d" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom5" data-dnid="10156"><a href="https://www.tradeforward.io/Partners/">More Info</a></p></div></div></div></div></div><div id="a18e09b5616215f183a1e0c3236e192a" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561630095e3de69df5d6e0760" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616301832362326411746151" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h2 class="wb-stl-custom7" data-dnid="10146"><a href="https://www.tradeforward.io/About/">about us</a><br>
 </h2></div><div id="a18e09b561630299236619b83ce21cd0" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom8" data-dnid="10148">At Trade Forward, we pride ourselves on being a premier network of international trade experts, dedicated to elevating Global Trade Management and Business Intelligence solutions. Our mission is to empower manufacturers and distributors around the world with cutting-edge software and strategic consulting services, tailored to meet the unique demands of the global market.</p>
</div><div id="a18e09b56163031d1c02e89f670bdcc4" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom5" data-dnid="10158"><a href="https://www.tradeforward.io/About/">Read More</a></p></div></div></div></div></div></div></div><div id="wb_footer_a18e09b5bc7400dd82335abe9162dd86" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616305b1c739b95b022d55a3" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b56163066cc29b20bd7d165b63" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616307c36c81d1292bcbc154" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom9" data-dnid="10170">17319 Inglewood Ln</p></div><div id="a18e09b5616308a2afabc15e33083881" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="10177">Follow Us</p></div><div id="a18e09b5616309bd9ce18af34d2a7cbf" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="10174">© 2023 Trade Forward LLC</p></div></div></div><div id="a18e09b561630adfec3669fa61952ca2" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b561630b44a9952b75bdf16797" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom9" data-dnid="10179">Huntersville, NC 28078</p></div><div id="a18e09b561630c3d6c7f779b7f8fa4fd" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap" style="height: 100%"><div class="wb-picture-wrapper" style="overflow: visible; display: flex"><a href="https://www.linkedin.com/company/trade-forward-llc/?viewAsMember=true" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="1793.982" height="1793.982" viewBox="0 0 1793.982 1793.982" style="direction: ltr; color:#ffffff"><text x="129.501415" y="1537.02" font-size="1792" fill="currentColor" style='font-family: "FontAwesome"'></text></svg></a></div></div></div><div id="a18e09b561630d488a93171b97e6c1b4" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="10172">1-800-925-9557</p></div></div></div></div></div><div id="wb_footer_c" class="wb_element" data-plugin="WB_Footer" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#footer, #footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div></div></div>{{hr_out}}</body>
</html>
