<!DOCTYPE html>
<html lang="en-us">
<head>
	<script type="text/javascript">
			</script>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title><?php echo htmlspecialchars((isset($seoTitle) && $seoTitle !== "") ? $seoTitle : "About"); ?></title>
	<base href="{{base_url}}" />
	<?php echo isset($sitemapUrls) ? generateCanonicalUrl($sitemapUrls) : ""; ?>	
	
						<meta name="viewport" content="width=device-width, initial-scale=1" />
					<meta name="description" content="<?php echo htmlspecialchars((isset($seoDescription) && $seoDescription !== "") ? $seoDescription : "About"); ?>" />
			<meta name="keywords" content="<?php echo htmlspecialchars((isset($seoKeywords) && $seoKeywords !== "") ? $seoKeywords : "About"); ?>" />
		
	<!-- Facebook Open Graph -->
		<meta property="og:title" content="<?php echo htmlspecialchars((isset($seoTitle) && $seoTitle !== "") ? $seoTitle : "About"); ?>" />
			<meta property="og:description" content="<?php echo htmlspecialchars((isset($seoDescription) && $seoDescription !== "") ? $seoDescription : "About"); ?>" />
			<meta property="og:image" content="<?php echo htmlspecialchars((isset($seoImage) && $seoImage !== "") ? "{{base_url}}".$seoImage : ""); ?>" />
			<meta property="og:type" content="article" />
			<meta property="og:url" content="{{curr_url}}" />
		<!-- Facebook Open Graph end -->

		<meta name="generator" content="Website Builder" />
			<script src="js/common-bundle.js?ts=20240424225725" type="text/javascript"></script>
	<script src="js/a18e09b5bc740135dc25e04ce2012ced-bundle.js?ts=20240424225725" type="text/javascript"></script>
	<link href="css/common-bundle.css?ts=20240424225725" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin,latin-ext,vietnamese" rel="stylesheet" type="text/css" />
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin,latin-ext,vietnamese" rel="stylesheet" type="text/css" />
	<link href="css/a18e09b5bc740135dc25e04ce2012ced-bundle.css?ts=20240424225725" rel="stylesheet" type="text/css" id="wb-page-stylesheet" />
	<ga-code/>
	<script type="text/javascript">
	window.useTrailingSlashes = true;
	window.disableRightClick = false;
	window.currLang = 'en';
</script>
		
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<![endif]-->

		<script type="text/javascript">
		$(function () {
<?php $wb_form_send_success = popSessionOrGlobalVar("wb_form_send_success"); ?>
<?php if (($wb_form_send_state = popSessionOrGlobalVar("wb_form_send_state"))) { ?>
	<?php if (($wb_form_popup_mode = popSessionOrGlobalVar("wb_form_popup_mode")) && (isset($wbPopupMode) && $wbPopupMode)) { ?>
		if (window !== window.parent && window.parent.postMessage) {
			var data = {
				event: "wb_contact_form_sent",
				data: {
					state: "<?php echo str_replace('"', '\"', $wb_form_send_state); ?>",
					type: "<?php echo $wb_form_send_success ? "success" : "danger"; ?>"
				}
			};
			window.parent.postMessage(data, "<?php echo str_replace('"', '\"', popSessionOrGlobalVar("wb_target_origin")); ?>");
		}
	<?php $wb_form_send_success = false; $wb_form_send_state = null; $wb_form_popup_mode = false; ?>
	<?php } else { ?>
		wb_show_alert("<?php echo str_replace(array('"', "\r", "\n"), array('\"', "", "<br/>"), $wb_form_send_state); ?>", "<?php echo $wb_form_send_success ? "success" : "danger"; ?>");
	<?php } ?>
<?php } ?>
});    </script>
</head>


<body class="site site-lang-en<?php if (isset($wbPopupMode) && $wbPopupMode) echo ' popup-mode'; ?> " <?php ?>><div id="wb_root" class="root wb-layout-vertical"><div class="wb_sbg"></div><div id="wb_header_a18e09b5bc740135dc25e04ce2012ced" class="wb_element wb-sticky wb-layout-element" data-plugin="LayoutElement" data-h-align="center" data-v-align="top"><div class="wb_content wb-layout-vertical"><div id="a18e09b56165088c551514ee334176e7" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616509bcfc3046a7fccfaf29" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b561650a127857d146be15a312" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><a href="https://www.tradeforward.io/"><img alt="" src="gallery_gen/5629ab6b9d1e0502d030cf8e37f5d42e_596x188_fit.jpg?ts=1713988648"></a></div></div></div><div id="a18e09b561650b25be90c73d08ee9932" class="wb_element wb-menu wb-prevent-layout-click wb-menu-mobile" data-plugin="Menu"><a class="btn btn-default btn-collapser"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a><ul class="hmenu" dir="ltr"><li class=""><a href="{{base_url}}">Home</a></li><li class="wb_this_page_menu_item"><a href="About/">About</a></li><li class=""><a href="Analytics/">Analytics</a></li><li class=""><a href="Services/">Services</a></li><li class=""><a href="Partners/">Partners</a></li><li class=""><a href="Contact/">Contact</a></li></ul><div class="clearfix"></div></div></div></div></div></div></div></div><div id="wb_main_a18e09b5bc740135dc25e04ce2012ced" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561650d8fc878783fadff374c" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b561650e6369550845371d8795" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-absolute"></div></div></div></div><div id="a18e09b561650f014a193908509c4b00" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561651018752ff9e8d26d79e1" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561651160c064b1a5afcb9bfd" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h5 class="wb-stl-custom1" data-dnid="20122">EMPOWERING CLIENTS THROUGH EXPERTISE &amp; INNOVATION</h5>
</div></div></div></div></div><div id="a18e09b561651215c554e809ef289b4b" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616513aa779a421117e49b0e" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b56165142ce661ef765a6cec16" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom11" data-dnid="20120">In a landscape marked by rapid changes and complex challenges, Trade Forward stands as a dynamic ally. We are committed to helping organizations navigate the intricacies of their international supply chains, offering adaptable, insightful, and forward-thinking strategies to enhance logistical and trade operations. Our approach is centered on flexibility and intelligence, ensuring our partners are equipped to achieve unprecedented levels of optimization.</p>
</div></div></div></div></div><div id="a18e09b56165157c3df6d2312dd19f0b" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b561660052db3ab6da0922e592" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b56166012d59fc3e764a1507a0" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616602b0c99af5cf2fbbaee4" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><img alt="" src="gallery_gen/36abac13ff07b76ff184f59bb8659803_564x582_fit.jpg?ts=1713988648"></div></div></div><div id="a18e09b5616603157998636ca9acbb1a" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-custom12" data-dnid="20129">allison tHOMPSON</h3></div><div id="a18e09b5616604b23b38fdd7784fc23e" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom13" data-dnid="20142">PARTNER</p>
</div><div id="a18e09b5616605c8efa8264392fde074" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom14" data-dnid="20131">Allison has spent a decade providing oversight of global trade content collection and quality assurance while delivering projects for global trade management providers. Prior to her work in trade, she managed the registration, billing, and on-site coordination of events for large professional associations.</p><p class="wb-stl-custom15" data-dnid="20133"> </p><p class="wb-stl-custom14" data-dnid="20135">Trade Forward has grown out of Allison’s desire to provide customers with professional services that deliver value and foster long term relationships.</p></div></div></div><div id="a18e09b561660631506e409d952c6db4" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616607be2cd3db9af6e3eeee" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><img alt="" src="gallery_gen/a81c12fc70c33e1f2e8aa0aa3d8480a5_592x578_fit.jpg?ts=1713988648"></div></div></div><div id="a18e09b5616608c0bfed760f19e1ea55" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-custom12" data-dnid="20124">mIKE tHOMPSON</h3></div><div id="a18e09b56166090cfe26e8d3d2cee5f4" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom16" data-dnid="20126">PRESIDENT</p>
</div><div id="a18e09b561660a927a5e9d911d6a3358" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom14" data-dnid="20139">Mike has over 20 years of system design, process engineering, strategic consulting, data analytics, account management, project management, and quality assurance experience within a variety of markets.<br><br>
He is accountable for the design and implementation of various enterprise-wide applications, management of systems integration projects, and delivery of strategic consulting services while ensuring the highest level of client support.</p></div></div></div><div id="a18e09b561660b63cf8e97e6679c7801" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561660c60178e5e765a0d591f" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap"><div class="wb-picture-wrapper"><img alt="" src="gallery_gen/49ce0a0bd11febf2f43bc646fe1d1f87_700x648_fit.jpg?ts=1713988649"></div></div></div><div id="a18e09b561660d938640339b0f51da33" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><h3 class="wb-stl-custom12" data-dnid="20124">CHERYL MccAULEY</h3>
</div><div id="a18e09b561660e8b90fa76999279c63f" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom16" data-dnid="20126">PARTNER</p>
</div><div id="a18e09b5616700a337c19beea79c9ea1" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom14" data-dnid="20139">Cheryl is a career long global logistics and forwarding professional with a focus on export compliance and international documentation. She holds a PMP certificate and serves as a key account representative at Trade Forward.<br>
<br>
Cheryl has experience with TSA compliance, US Export compliance, FTR /AES Training, EAR/ITAR training, and Dangerous Goods training. She was a designated trainer in Hazmat awareness and a Dangerous good coordinator. </p>
</div></div></div></div></div></div></div></div></div><div id="wb_footer_a18e09b5bc740135dc25e04ce2012ced" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b5616702c228e6a33cba5c3da8" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-vertical"><div id="a18e09b561670399db7c2cc8b0dcb09b" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616704bc6e7a674906150d25" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom9" data-dnid="20148">17319 Inglewood Ln</p></div><div id="a18e09b5616705736b6df496f202de10" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="20155">Follow Us</p></div><div id="a18e09b5616706e158b649ccfc8d55f6" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="20152">© 2023 Trade Forward LLC</p></div></div></div><div id="a18e09b5616707cfccb4d00d67889333" class="wb_element wb-layout-element" data-plugin="LayoutElement"><div class="wb_content wb-layout-horizontal"><div id="a18e09b5616708c8733170981c9f9c90" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom9" data-dnid="20157">Huntersville, NC 28078</p></div><div id="a18e09b56167090e4039c15c37dbcc02" class="wb_element wb_element_picture" data-plugin="Picture" title=""><div class="wb_picture_wrap" style="height: 100%"><div class="wb-picture-wrapper" style="overflow: visible; display: flex"><a href="https://www.linkedin.com/company/trade-forward-llc/?viewAsMember=true" target="_blank"><svg xmlns="http://www.w3.org/2000/svg" width="1793.982" height="1793.982" viewBox="0 0 1793.982 1793.982" style="direction: ltr; color:#ffffff"><text x="129.501415" y="1537.02" font-size="1792" fill="currentColor" style='font-family: "FontAwesome"'></text></svg></a></div></div></div><div id="a18e09b561670aa671b23233dbfe7a45" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;"><p class="wb-stl-custom10" data-dnid="20150">1-800-925-9557</p></div></div></div></div></div><div id="wb_footer_c" class="wb_element" data-plugin="WB_Footer" style="text-align: center; width: 100%;"><div class="wb_footer"></div><script type="text/javascript">
			$(function() {
				var footer = $(".wb_footer");
				var html = (footer.html() + "").replace(/^\s+|\s+$/g, "");
				if (!html) {
					footer.parent().remove();
					footer = $("#footer, #footer .wb_cont_inner");
					footer.css({height: ""});
				}
			});
			</script></div></div></div></div>{{hr_out}}</body>
</html>
